param($name)

"Hello $name!"
Get-AzResourceGroup
New-AzStorageAccount -Name "asjdfbhf1234" -ResourceGroupName "test" -SkuName Standard_LRS -Location "CentralUS"
"Hello $name!"